import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
public class Chess{
	ImageIcon Rpawn=new ImageIcon("C:/Users/Marjan/workspace/Chese/Image/pawnt.png");
	ImageIcon Bpawn=new ImageIcon("C:/Users/Marjan/workspace/Chese/Image/pawno.png");
	ImageIcon Rknight=new ImageIcon("C:/Users/Marjan/workspace/Chese/Image/knightt.png");
	ImageIcon Bknight=new ImageIcon("C:/Users/Marjan/workspace/Chese/Image/knighto.png");
	ImageIcon Rbishop=new ImageIcon("C:/Users/Marjan/workspace/Chese/Image/bishopt.png");
	ImageIcon Bbishop=new ImageIcon("C:/Users/Marjan/workspace/Chese/Image/bishopo.png");
	ImageIcon Rking=new ImageIcon("C:/Users/Marjan/workspace/Chese/Image/kingt.png");
	ImageIcon Bking=new ImageIcon("C:/Users/Marjan/workspace/Chese/Image/kingo.png");
	ImageIcon Rqueen=new ImageIcon("C:/Users/Marjan/workspace/Chese/Image/queent.png");
	ImageIcon Bqueen=new ImageIcon("C:/Users/Marjan/workspace/Chese/Image/queeno.png");
	ImageIcon Rrook=new ImageIcon("C:/Users/Marjan/workspace/Chese/Image/rookt.png");
	ImageIcon Brook=new ImageIcon("C:/Users/Marjan/workspace/Chese/Image/rooko.png");
	Connection conn=null;
	boolean summ=true;
		Chess() {
					JFrame f=new JFrame("Chess");
					f.setVisible(true);	
					f.setBounds(100, 100, 600, 600);
					f.setLayout(new GridLayout(8,8));
					JButton b[]=new JButton[80];
					
					for(int i=1;i<=64;i++){		
						b[i]=new JButton();
						f.add(b[i]);
					}
					for(int i=9;i<=16;i++){
						b[i].setIcon(Rpawn);
					}
					for(int i=49;i<=56;i++){
						b[i].setIcon(Bpawn);
					}
					b[1].setIcon(Rrook);
					b[2].setIcon(Rknight);
					b[3].setIcon(Rbishop);
					b[4].setIcon(Rking);
					b[5].setIcon(Rqueen);
					b[6].setIcon(Rbishop);
					b[7].setIcon(Rknight);
					b[8].setIcon(Rrook);
					b[57].setIcon(Brook);
					b[58].setIcon(Bknight);
					b[59].setIcon(Bbishop);
					b[60].setIcon(Bking);
					b[61].setIcon(Bqueen);
					b[62].setIcon(Bbishop);
					b[63].setIcon(Bknight);
					b[64].setIcon(Brook);
					setColor(b);
					
					//conn=MySqlConnection.dbConnector();
//					try{
//					
//						String query=" insert into record (Match_No,First_Player_Name,Second_Player_Name,Result)values(?,?,?)";
//						PreparedStatement pst=conn.prepareStatement(query);
//						pst=conn.prepareStatement(query);
//						pst.setString(1, null);
//						pst.setString(2, fp.valueOf(fp));
//						pst.setString(3, sp.valueOf(sp));
//					
//					}catch(Exception e10){
//						System.out.println();
//					}	
					String fp=JOptionPane.showInputDialog(f,"First Player Name: ");
					String sp=JOptionPane.showInputDialog(f,"Second Player Name: ");
					for(int i=1;i<=64;i++){
						
						final int temp=i;
						b[temp].addActionListener(new ActionListener() {
							
							@Override
							public void actionPerformed(ActionEvent e) {
								if(RkingIsNull(b)){
									JOptionPane.showMessageDialog(f, sp.valueOf(sp)+" Wins");
								}
								else if(BkingIsNull(b)){
									JOptionPane.showMessageDialog(f, fp.valueOf(fp)+" Wins");
								}
								else{
									if(b[temp].getIcon()==Rpawn && b[temp].getBackground()!=Color.green && summ==true){
										setColor(b);
										RPColor(b,temp);
									}
									if(b[temp].getIcon()==Rrook && b[temp].getBackground()!=Color.green && summ==true){
										setColor(b);
										RRColor(b,temp);
									}
									if(b[temp].getIcon()==Rknight && b[temp].getBackground()!=Color.green && summ==true){
										setColor(b);
										RKNColor(b,temp);
									}
									if(b[temp].getIcon()==Rbishop && b[temp].getBackground()!=Color.green && summ==true){
										setColor(b);
										RBColor(b,temp);
									}
									if(b[temp].getIcon()==Rqueen && b[temp].getBackground()!=Color.green && summ==true){
										setColor(b);
										RQColor(b,temp);
									}
									if(b[temp].getIcon()==Rking && b[temp].getBackground()!=Color.green && summ==true){
										setColor(b);
										RKColor(b,temp);
									}
									if(b[temp].getIcon()==Bpawn && b[temp].getBackground()!=Color.green && summ==false){
										setColor(b);
										BPColor(b,temp);
									}
									if(b[temp].getIcon()==Brook && b[temp].getBackground()!=Color.green && summ==false){
										setColor(b);
										BRColor(b,temp);
									}
									if(b[temp].getIcon()==Bknight && b[temp].getBackground()!=Color.green && summ==false){
										setColor(b);
										BKNColor(b,temp);
									}
									if(b[temp].getIcon()==Bbishop && b[temp].getBackground()!=Color.green && summ==false){
										setColor(b);
										BBColor(b,temp);
									}
									if(b[temp].getIcon()==Bqueen && b[temp].getBackground()!=Color.green && summ==false){
										setColor(b);
										BQColor(b,temp);
									}
									if(b[temp].getIcon()==Bking && b[temp].getBackground()!=Color.green && summ==false){
										setColor(b);
										BKColor(b,temp);
									}
									else if(b[temp].getBackground()==Color.cyan || b[temp].getBackground()==Color.green){
										
										for(int i=1;i<=64;i++){
											Icon icon=b[i].getIcon();
											if(b[i].getBackground()==Color.yellow){
												b[i].setIcon(null);
												if(b[temp].getIcon()==Rking){
													b[temp].setIcon(icon);
													setColor(b);
													JOptionPane.showMessageDialog(f, sp.valueOf(sp)+" Wins");
													try{
														String query="insert into record (First_Player_Name,Second_Player_Name,Result)values(?,?,?)";
														PreparedStatement pst=conn.prepareStatement(query);
														pst.setString(4, sp.valueOf(sp)+" Wins");
														
													}catch(Exception e10){
														System.out.println();
													}
												}
												else if(b[temp].getIcon()==Bking){
													b[temp].setIcon(icon);
													setColor(b);
													JOptionPane.showMessageDialog(f, fp.valueOf(fp)+" Wins");
													try{
														String query="insert into record (First_Player_Name,Second_Player_Name,Result)values(?,?,?)";
														PreparedStatement pst=conn.prepareStatement(query);
														pst.setString(4, fp.valueOf(fp)+" Wins");
														
													}catch(Exception e10){
														e10.printStackTrace();
													}
												}
												else{
													b[temp].setIcon(icon);
													setColor(b);
													if(b[temp].getIcon()==Rpawn && temp>=57 && temp<=64){
														b[temp].setIcon(Rqueen);
													}
													if(b[temp].getIcon()==Bpawn && temp>=1 && temp<=8){
														b[temp].setIcon(Bqueen);
													}
												}
												if(GetRed(b,temp)){
													summ=false;
												}
												else{
													summ=true;
												}
											}
										}
									}
								}
							}
						});
					}	
		}
		void setColor(JButton b[]){
			int sum=0,count=0;
			Color c=new Color(191,140,89);
			Color c2=new Color(235,209,160);
			for(int i=1;i<=64;i+=1){
				if(count%8==0){
					if(sum==0){
						sum=1;
					}
					else if(sum==1){
						sum=0;
					}
				}
				if(sum==0){
					b[i].setBackground(c);
					sum=1;
					count++;
				}
				else if(sum==1){
					b[i].setBackground(c2);
					sum=0;
					count++;
				}
			}
		}
		void RPColor(JButton ar[], int temp){
			ar[temp].setBackground(Color.yellow);
			if(ar[temp+8].getIcon()==null){
				ar[temp+8].setBackground(Color.cyan);
				if(ar[temp+16].getIcon()==null && temp>=9 && temp<=16){
					ar[temp+16].setBackground(Color.cyan);
				}
			}
			if(temp==9 || temp==17 || temp==25 || temp==33 || temp==41 || temp==49){
				if(GetBlue(ar,temp+9)){
					ar[temp+9].setBackground(Color.GREEN);
				}
			}
			else if(temp==16 || temp==24 || temp==32 || temp==40 || temp==48 || temp==56){
				if(GetBlue(ar,temp+7)){
					ar[temp+7].setBackground(Color.green);
				}
			}
			else{
				if(GetBlue(ar,temp+7)){
					ar[temp+7].setBackground(Color.green);
				}
				if(GetBlue(ar,temp+9)){
					ar[temp+9].setBackground(Color.green);
				}
			}
		}
		void RRColor(JButton ar[],int temp){
			ar[temp].setBackground(Color.YELLOW);
			for(int i=temp+8;i<=64;i+=8){
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=57 && i<=64){
					break;
				}
			}
			for(int i=temp-8;i>=1;i-=8){
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=1 && i<=8){
					break;
				}
			}
			for(int i=temp+1;i<=temp+7;i++){
				if(temp==8 || temp==16 || temp==24 || temp==32 || temp==40 || temp==48 || temp==56 || temp==64){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i==8 || i==16 || i==24 || i==32 || i==40 || i==48 || i==56 || i==64){
					break;
				}
			}
			for(int i=temp-1;i>=temp-7;i--){
				if(temp==1 || temp==9 || temp==17 || temp==25 || temp==33 || temp==41 || temp==49 || temp==57){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i==1 || i==9 || i==17 || i==25 || i==33 || i==41 || i==49 || i==57){
					break;
				}
			}
		}
		void RBColor(JButton ar[],int temp){
			ar[temp].setBackground(Color.YELLOW);
			for(int i=temp+9;i<=64;i+=9){
				if(temp>=56 && temp<=64 || temp==8 || temp==16 || temp==24 || temp==32 || temp==40 || temp==48){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=58 && i<=64 || i==8 || i==16 || i==24 || i==32 || i==40 || i==48){
					break;
				}
			}
			for(int i=temp+7;i<=64;i+=7){
				if(temp>=57 && temp<=64 || temp==1 || temp==9 || temp==17 || temp==25 || temp==33 || temp==41 || temp==49){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=57 && i<=63 || i==9 || i==17 || i==25 || i==33 || i==41 || i==49){
					break;
				}
			}
			for(int i=temp-7;i>=1;i-=7){
				if(temp>=1 && temp<=8 || temp==16 || temp==24 || temp==32 || temp==40 || temp==48 || temp==56 || temp==64){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=2 && i<=8 || i==16 || i==24 || i==32 || i==40 || i==48 || i==56){
					break;
				}
			}
			for(int i=temp-9;i>=1;i-=9){
				if(temp>=1 && temp<=8 || temp==9 || temp==17 || temp==25 || temp==33 || temp==41 || temp==49 || temp==57){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=1 && i<=7 || i==9 || i==17 || i==25 || i==33 || i==41 || i==49){
					break;
				}
			}
		}
		void RQColor(JButton ar[],int temp){
			ar[temp].setBackground(Color.YELLOW);
			for(int i=temp+8;i<=64;i+=8){
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=57 && i<=64){
					break;
				}
			}
			for(int i=temp-8;i>=1;i-=8){
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=1 && i<=8){
					break;
				}
			}
			for(int i=temp+1;i<=temp+7;i++){
				if(temp==8 || temp==16 || temp==24 || temp==32 || temp==40 || temp==48 || temp==56 || temp==64){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i==8 || i==16 || i==24 || i==32 || i==40 || i==48 || i==56 || i==64){
					break;
				}
			}
			for(int i=temp-1;i>=temp-7;i--){
				if(temp==1 || temp==9 || temp==17 || temp==25 || temp==33 || temp==41 || temp==49 || temp==57){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i==1 || i==9 || i==17 || i==25 || i==33 || i==41 || i==49 || i==57){
					break;
				}
			}
			for(int i=temp+9;i<=64;i+=9){
				if(temp>=56 && temp<=64 || temp==8 || temp==16 || temp==24 || temp==32 || temp==40 || temp==48){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=58 && i<=64 || i==8 || i==16 || i==24 || i==32 || i==40 || i==48){
					break;
				}
			}
			for(int i=temp+7;i<=64;i+=7){
				if(temp>=57 && temp<=64 || temp==1 || temp==9 || temp==17 || temp==25 || temp==33 || temp==41 || temp==49){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=57 && i<=63 || i==9 || i==17 || i==25 || i==33 || i==41 || i==49){
					break;
				}
			}
			for(int i=temp-7;i>=1;i-=7){
				if(temp>=1 && temp<=8 || temp==16 || temp==24 || temp==32 || temp==40 || temp==48 || temp==56 || temp==64){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=2 && i<=8 || i==16 || i==24 || i==32 || i==40 || i==48 || i==56){
					break;
				}
			}
			for(int i=temp-9;i>=1;i-=9){
				if(temp>=1 && temp<=8 || temp==9 || temp==17 || temp==25 || temp==33 || temp==41 || temp==49 || temp==57){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=1 && i<=7 || i==9 || i==17 || i==25 || i==33 || i==41 || i==49){
					break;
				}
			}
		}
		void RKColor(JButton ar[],int temp){
			ar[temp].setBackground(Color.YELLOW);
			for(int i=temp+8;i<=64;i+=8){
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
					break;
				}
			}
			for(int i=temp-8;i>=1;i-=8){
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
					break;
				}
			}
			for(int i=temp+1;i<=temp+7;i++){
				if(temp==8 || temp==16 || temp==24 || temp==32 || temp==40 || temp==48 || temp==56 || temp==64){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
					break;
				}
			}
			for(int i=temp-1;i>=temp-7;i--){
				if(temp==1 || temp==9 || temp==17 || temp==25 || temp==33 || temp==41 || temp==49 || temp==57){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
					break;
				}
			}
			for(int i=temp+9;i<=64;i+=9){
				if(temp>=56 && temp<=64 || temp==8 || temp==16 || temp==24 || temp==32 || temp==40 || temp==48){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
					break;
				}
			}
			for(int i=temp+7;i<=64;i+=7){
				if(temp>=57 && temp<=64 || temp==1 || temp==9 || temp==17 || temp==25 || temp==33 || temp==41 || temp==49){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
					break;
				}
			}
			for(int i=temp-7;i>=1;i-=7){
				if(temp>=1 && temp<=8 || temp==16 || temp==24 || temp==32 || temp==40 || temp==48 || temp==56 || temp==64){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
					break;
				}
			}
			for(int i=temp-9;i>=1;i-=9){
				if(temp>=1 && temp<=8 || temp==9 || temp==17 || temp==25 || temp==33 || temp==41 || temp==49 || temp==57){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetBlue(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
					break;
				}
			}
		}
		void BPColor(JButton ar[], int temp){
			ar[temp].setBackground(Color.yellow);
			if(ar[temp-8].getIcon()==null){
				ar[temp-8].setBackground(Color.cyan);
				if(ar[temp-16].getIcon()==null && temp>=49 && temp<=56){
					ar[temp-16].setBackground(Color.cyan);
				}
			}
			if(temp==9 || temp==17 || temp==25 || temp==33 || temp==41 || temp==49){
				if(GetRed(ar,temp-7)){
					ar[temp-7].setBackground(Color.GREEN);
				}
			}
			else if(temp==16 || temp==24 || temp==32 || temp==40 || temp==48 || temp==56){
				if(GetRed(ar,temp-9)){
					ar[temp-9].setBackground(Color.green);
				}
			}
			else{
				if(GetRed(ar,temp-7)){
					ar[temp-7].setBackground(Color.green);
				}
				if(GetRed(ar,temp-9)){
					ar[temp-9].setBackground(Color.green);
				}
			}
		}		void BRColor(JButton ar[],int temp){
			ar[temp].setBackground(Color.YELLOW);
			for(int i=temp+8;i<=64;i+=8){
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=57 && i<=64){
					break;
				}
			}
			for(int i=temp-8;i>=1;i-=8){
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=1 && i<=8){
					break;
				}
			}
			for(int i=temp+1;i<=temp+7;i++){
				if(temp==8 || temp==16 || temp==24 || temp==32 || temp==40 || temp==48 || temp==56 || temp==64){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i==8 || i==16 || i==24 || i==32 || i==40 || i==48 || i==56 || i==64){
					break;
				}
			}
			for(int i=temp-1;i>=temp-7;i--){
				if(temp==1 || temp==9 || temp==17 || temp==25 || temp==33 || temp==41 || temp==49 || temp==57){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i==1 || i==9 || i==17 || i==25 || i==33 || i==41 || i==49 || i==57){
					break;
				}
			}
		}
		void BBColor(JButton ar[],int temp){
			ar[temp].setBackground(Color.YELLOW);
			for(int i=temp+9;i<=64;i+=9){
				if(temp>=56 && temp<=64 || temp==8 || temp==16 || temp==24 || temp==32 || temp==40 || temp==48){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=58 && i<=64 || i==8 || i==16 || i==24 || i==32 || i==40 || i==48){
					break;
				}
			}
			for(int i=temp+7;i<=64;i+=7){
				if(temp>=57 && temp<=64 || temp==1 || temp==9 || temp==17 || temp==25 || temp==33 || temp==41 || temp==49){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=57 && i<=63 || i==9 || i==17 || i==25 || i==33 || i==41 || i==49){
					break;
				}
			}
			for(int i=temp-7;i>=1;i-=7){
				if(temp>=1 && temp<=8 || temp==16 || temp==24 || temp==32 || temp==40 || temp==48 || temp==56 || temp==64){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=2 && i<=8 || i==16 || i==24 || i==32 || i==40 || i==48 || i==56){
					break;
				}
			}
			for(int i=temp-9;i>=1;i-=9){
				if(temp>=1 && temp<=8 || temp==9 || temp==17 || temp==25 || temp==33 || temp==41 || temp==49 || temp==57){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=1 && i<=7 || i==9 || i==17 || i==25 || i==33 || i==41 || i==49){
					break;
				}
			}
		}
		void BQColor(JButton ar[],int temp){
			ar[temp].setBackground(Color.YELLOW);
			for(int i=temp+8;i<=64;i+=8){
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=57 && i<=64){
					break;
				}
			}
			for(int i=temp-8;i>=1;i-=8){
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=1 && i<=8){
					break;
				}
			}
			for(int i=temp+1;i<=temp+7;i++){
				if(temp==8 || temp==16 || temp==24 || temp==32 || temp==40 || temp==48 || temp==56 || temp==64){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i==8 || i==16 || i==24 || i==32 || i==40 || i==48 || i==56 || i==64){
					break;
				}
			}
			for(int i=temp-1;i>=temp-7;i--){
				if(temp==1 || temp==9 || temp==17 || temp==25 || temp==33 || temp==41 || temp==49 || temp==57){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i==1 || i==9 || i==17 || i==25 || i==33 || i==41 || i==49 || i==57){
					break;
				}
			}
			for(int i=temp+9;i<=64;i+=9){
				if(temp>=56 && temp<=64 || temp==8 || temp==16 || temp==24 || temp==32 || temp==40 || temp==48){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=58 && i<=64 || i==8 || i==16 || i==24 || i==32 || i==40 || i==48){
					break;
				}
			}
			for(int i=temp+7;i<=64;i+=7){
				if(temp>=57 && temp<=64 || temp==1 || temp==9 || temp==17 || temp==25 || temp==33 || temp==41 || temp==49){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=57 && i<=63 || i==9 || i==17 || i==25 || i==33 || i==41 || i==49){
					break;
				}
			}
			for(int i=temp-7;i>=1;i-=7){
				if(temp>=1 && temp<=8 || temp==16 || temp==24 || temp==32 || temp==40 || temp==48 || temp==56 || temp==64){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=2 && i<=8 || i==16 || i==24 || i==32 || i==40 || i==48 || i==56){
					break;
				}
			}
			for(int i=temp-9;i>=1;i-=9){
				if(temp>=1 && temp<=8 || temp==9 || temp==17 || temp==25 || temp==33 || temp==41 || temp==49 || temp==57){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
				}
				if(i>=1 && i<=7 || i==9 || i==17 || i==25 || i==33 || i==41 || i==49){
					break;
				}
			}
		}
		void BKColor(JButton ar[],int temp){
			ar[temp].setBackground(Color.YELLOW);
			for(int i=temp+8;i<=64;i+=8){
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
					break;
				}
			}
			for(int i=temp-8;i>=1;i-=8){
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
					break;
				}
			}
			for(int i=temp+1;i<=temp+7;i++){
				if(temp==8 || temp==16 || temp==24 || temp==32 || temp==40 || temp==48 || temp==56 || temp==64){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
					break;
				}
			}
			for(int i=temp-1;i>=temp-7;i--){
				if(temp==1 || temp==9 || temp==17 || temp==25 || temp==33 || temp==41 || temp==49 || temp==57){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
					break;
				}
			}
			for(int i=temp+9;i<=64;i+=9){
				if(temp>=56 && temp<=64 || temp==8 || temp==16 || temp==24 || temp==32 || temp==40 || temp==48){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
					break;
				}
			}
			for(int i=temp+7;i<=64;i+=7){
				if(temp>=57 && temp<=64 || temp==1 || temp==9 || temp==17 || temp==25 || temp==33 || temp==41 || temp==49){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
					break;
				}
			}
			for(int i=temp-7;i>=1;i-=7){
				if(temp>=1 && temp<=8 || temp==16 || temp==24 || temp==32 || temp==40 || temp==48 || temp==56 || temp==64){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
					break;
				}
			}
			for(int i=temp-9;i>=1;i-=9){
				if(temp>=1 && temp<=8 || temp==9 || temp==17 || temp==25 || temp==33 || temp==41 || temp==49 || temp==57){
					break;
				}
				if(ar[i].getIcon()!=null){
					if(GetRed(ar,i)){
						ar[i].setBackground(Color.green);
					}
					break;
				}
				else{
					ar[i].setBackground(Color.cyan);
					break;
				}
			}
		}
		void RKNColor(JButton ar[],int temp){
			ar[temp].setBackground(Color.yellow);
			try{
			if(temp>=1 && temp<=16 || temp>=49 && temp<=64 || temp==17 || temp==18 || temp==25 || temp==26 || temp==33 || temp==34 || temp==41 || temp==42 || temp==23 || temp==24 || temp==31 || temp==32 || temp==39 || temp==40 || temp==47 || temp==48){
				if(temp>=3 && temp<=6 || temp>=11 && temp<=14){
					if(ar[temp+6].getIcon()!=null){
						if(GetBlue(ar, temp+6)){
							ar[temp+6].setBackground(Color.green);
						}
					}
					else{
						ar[temp+6].setBackground(Color.cyan);
					}
					if(ar[temp+10].getIcon()!=null){
						if(GetBlue(ar, temp+10)){
							ar[temp+10].setBackground(Color.green);
						}
					}
					else{
						ar[temp+10].setBackground(Color.cyan);
					}
					if(ar[temp+15].getIcon()!=null){
						if(GetBlue(ar, temp+15)){
							ar[temp+15].setBackground(Color.green);
						}
					}
					else{
						ar[temp+15].setBackground(Color.cyan);
					}
					if(ar[temp+17].getIcon()!=null){
						if(GetBlue(ar, temp+17)){
							ar[temp+17].setBackground(Color.green);
						}
					}
					else{
						ar[temp+17].setBackground(Color.cyan);
					}
					if(ar[temp-6].getIcon()!=null){
						if(GetBlue(ar, temp-6)){
							ar[temp-6].setBackground(Color.green);
						}
					}
					else{
						ar[temp-6].setBackground(Color.cyan);
					}
					if(ar[temp-10].getIcon()!=null){
						if(GetBlue(ar, temp-10)){
							ar[temp-10].setBackground(Color.green);
						}
					}
					else{
						ar[temp-10].setBackground(Color.cyan);
					}
				}
				else if(temp>=51 && temp<=54 || temp>=59 && temp<=62){
						if(ar[temp-6].getIcon()!=null){
							if(GetBlue(ar, temp-6)){
								ar[temp-6].setBackground(Color.green);
							}
						}
						else{
							ar[temp-6].setBackground(Color.cyan);
						}
						if(ar[temp-10].getIcon()!=null){
							if(GetBlue(ar, temp-10)){
								ar[temp-10].setBackground(Color.green);
							}
						}
						else{
							ar[temp-10].setBackground(Color.cyan);
						}
						if(ar[temp-15].getIcon()!=null){
							if(GetBlue(ar, temp-15)){
								ar[temp-15].setBackground(Color.green);
							}
						}
						else{
							ar[temp-15].setBackground(Color.cyan);
						}
						if(ar[temp-17].getIcon()!=null){
							if(GetBlue(ar, temp-17)){
								ar[temp-17].setBackground(Color.green);
							}
						}
						else{
							ar[temp-17].setBackground(Color.cyan);
						}
						if(ar[temp+6].getIcon()!=null){
							if(GetBlue(ar, temp+6)){
								ar[temp+6].setBackground(Color.green);
							}
						}
						else{
							ar[temp+6].setBackground(Color.cyan);
						}
						if(ar[temp+10].getIcon()!=null){
							if(GetBlue(ar, temp+10)){
								ar[temp+10].setBackground(Color.green);
							}
						}
						else{
							ar[temp+10].setBackground(Color.cyan);
						}
					}
					else if(temp==1 || temp==9 || temp==17 || temp==25 || temp==33 || temp==41 || temp==49 || temp==57){
						try{
							if(ar[temp+10].getIcon()!=null){
							if(GetBlue(ar, temp+10)){
								ar[temp+10].setBackground(Color.green);
							}
						}
						else{
							ar[temp+10].setBackground(Color.cyan);
						}
						}catch(Exception e){
							
						}
						try{
						if(ar[temp+17].getIcon()!=null){
							if(GetBlue(ar, temp+17)){
								ar[temp+17].setBackground(Color.green);
							}
						}
						else{
							ar[temp+17].setBackground(Color.cyan);
						}
						}catch(Exception e2){
							System.out.println();
						}
						try{
						if(ar[temp-6].getIcon()!=null){
							if(GetBlue(ar, temp-6)){
								ar[temp-6].setBackground(Color.green);
							}
						}
						else{
							ar[temp-6].setBackground(Color.cyan);
						}
						}catch(Exception e3){
							System.out.println();
						}
						if(ar[temp-15].getIcon()!=null){
							if(GetBlue(ar, temp-15)){
								ar[temp-15].setBackground(Color.green);
							}
						}
						else{
							ar[temp-15].setBackground(Color.cyan);
						}
					}
					else if(temp==2 || temp==10 || temp==18 || temp==26 || temp==34 || temp==42 || temp==50 || temp==58){
						try{
						if(ar[temp+10].getIcon()!=null){
							if(GetBlue(ar, temp+10)){
								ar[temp+10].setBackground(Color.green);
							}
						}
						else{
							ar[temp+10].setBackground(Color.cyan);
						}
						}catch(Exception e){
							System.out.println();
						}
						try{
						if(ar[temp+15].getIcon()!=null){
							if(GetBlue(ar, temp+15)){
								ar[temp+15].setBackground(Color.green);
							}
						}
						else{
							ar[temp+15].setBackground(Color.cyan);
						}
						}catch(Exception e2){
							System.out.println();
						}
						try{
						if(ar[temp+17].getIcon()!=null){
							if(GetBlue(ar, temp+17)){
								ar[temp+17].setBackground(Color.green);
							}
						}
						else{
							ar[temp+17].setBackground(Color.cyan);
						}
						}catch(Exception e3){
							System.out.println();
						}
						try{
						if(ar[temp-6].getIcon()!=null){
							if(GetBlue(ar, temp-6)){
								ar[temp-6].setBackground(Color.green);
							}
						}
						else{
							ar[temp-6].setBackground(Color.cyan);
						}
						}catch(Exception e4){
							System.out.println();
						}
						try{
						if(ar[temp-15].getIcon()!=null){
							if(GetBlue(ar, temp-15)){
								ar[temp-15].setBackground(Color.green);
							}
						}
						else{
							ar[temp-15].setBackground(Color.cyan);
						}
						}catch(Exception e5){
							System.out.println();
						}
						if(ar[temp-17].getIcon()!=null){
							if(GetBlue(ar, temp-17)){
								ar[temp-17].setBackground(Color.green);
							}
						}
						else{
							ar[temp-17].setBackground(Color.cyan);
						}
					}		
					else if(temp==8 || temp==16 || temp==24 || temp==32 || temp==40 || temp==48 || temp==56 || temp==64){
						try{
						if(ar[temp+6].getIcon()!=null){
							if(GetBlue(ar, temp+6)){
								ar[temp+6].setBackground(Color.green);
							}
						}
						else{
							ar[temp+6].setBackground(Color.cyan);
						}
						}catch(Exception e2){
							System.out.println();
						}
						try{
						if(ar[temp-10].getIcon()!=null){
							if(GetBlue(ar, temp-10)){
								ar[temp-10].setBackground(Color.green);
							}
						}
						else{
							ar[temp-10].setBackground(Color.cyan);
						}
						}catch(Exception e3){
							System.out.println();
						}
						try{
						if(ar[temp+15].getIcon()!=null){
							if(GetBlue(ar, temp+15)){
								ar[temp+15].setBackground(Color.green);
							}
						}
						else{
							ar[temp+15].setBackground(Color.cyan);
						}
						}catch(Exception e4){
							System.out.println();
						}
						if(ar[temp-17].getIcon()!=null){
							if(GetBlue(ar, temp-17)){
								ar[temp-17].setBackground(Color.green);
							}
						}
						else{
							ar[temp-17].setBackground(Color.cyan);
						}
					}
					else if(temp==7 || temp==15 || temp==23 || temp==31 || temp==39 || temp==47 || temp==55 || temp==63){
						try{
						if(ar[temp+6].getIcon()!=null){
							if(GetBlue(ar, temp+6)){
								ar[temp+6].setBackground(Color.green);
							}
						}
						else{
							ar[temp+6].setBackground(Color.cyan);
						}
						}catch(Exception e){
							System.out.println();
						}
						try{
						if(ar[temp+15].getIcon()!=null){
							if(GetBlue(ar, temp+15)){
								ar[temp+15].setBackground(Color.green);
							}
						}
						else{
							ar[temp+15].setBackground(Color.cyan);
						}
						}catch(Exception e2){
							System.out.println();
						}
						try{
						if(ar[temp+17].getIcon()!=null){
							if(GetBlue(ar, temp+17)){
								ar[temp+17].setBackground(Color.green);
							}
						}
						else{
							ar[temp+17].setBackground(Color.cyan);
						}
						}catch(Exception e3){
							System.out.println();
						}
						try{
						if(ar[temp-10].getIcon()!=null){
							if(GetBlue(ar, temp-10)){
								ar[temp-10].setBackground(Color.green);
							}
						}
						else{
							ar[temp-10].setBackground(Color.cyan);
						}
						}catch(Exception e4){
							System.out.println();
						}
						try{
						if(ar[temp-15].getIcon()!=null){
							if(GetBlue(ar, temp-15)){
								ar[temp-15].setBackground(Color.green);
							}
						}
						else{
							ar[temp-15].setBackground(Color.cyan);
						}
						}catch(Exception e5){
							System.out.println();
						}
						if(ar[temp-17].getIcon()!=null){
							if(GetBlue(ar, temp-17)){
								ar[temp-17].setBackground(Color.green);
							}
						}
						else{
							ar[temp-17].setBackground(Color.cyan);
						}
					}
			}
			else{
				if(ar[temp+6].getIcon()!=null){
					if(GetBlue(ar, temp+6)){
						ar[temp+6].setBackground(Color.green);
					}
				}
				else{
					ar[temp+6].setBackground(Color.cyan);
				}
				if(ar[temp+10].getIcon()!=null){
					if(GetBlue(ar, temp+10)){
						ar[temp+10].setBackground(Color.green);
					}
				}
				else{
					ar[temp+10].setBackground(Color.cyan);
				}
				if(ar[temp+15].getIcon()!=null){
					if(GetBlue(ar, temp+15)){
						ar[temp+15].setBackground(Color.green);
					}
				}
				else{
					ar[temp+15].setBackground(Color.cyan);
				}
				if(ar[temp+17].getIcon()!=null){
					if(GetBlue(ar, temp+17)){
						ar[temp+17].setBackground(Color.green);
					}
				}
				else{
					ar[temp+17].setBackground(Color.cyan);
				}
				if(ar[temp-6].getIcon()!=null){
					if(GetBlue(ar, temp-6)){
						ar[temp-6].setBackground(Color.green);
					}
				}
				else{
					ar[temp-6].setBackground(Color.cyan);
				}
				if(ar[temp-10].getIcon()!=null){
					if(GetBlue(ar, temp-10)){
						ar[temp-10].setBackground(Color.green);
					}
				}
				else{
					ar[temp-10].setBackground(Color.cyan);
				}
				if(ar[temp-15].getIcon()!=null){
					if(GetBlue(ar, temp-15)){
						ar[temp-15].setBackground(Color.green);
					}
				}
				else{
					ar[temp-15].setBackground(Color.cyan);
				}
				if(ar[temp-17].getIcon()!=null){
					if(GetBlue(ar, temp-17)){
						ar[temp-17].setBackground(Color.green);
					}
				}
				else{
					ar[temp-17].setBackground(Color.cyan);
				}
			}
			}catch(Exception e){
				System.out.println();
			}
		}
		void BKNColor(JButton ar[],int temp){
			ar[temp].setBackground(Color.yellow);
			try{
			if(temp>=1 && temp<=16 || temp>=49 && temp<=64 || temp==17 || temp==18 || temp==25 || temp==26 || temp==33 || temp==34 || temp==41 || temp==42 || temp==23 || temp==24 || temp==31 || temp==32 || temp==39 || temp==40 || temp==47 || temp==48){
				if(temp>=3 && temp<=6 || temp>=11 && temp<=14){
					if(ar[temp+6].getIcon()!=null){
						if(GetRed(ar, temp+6)){
							ar[temp+6].setBackground(Color.green);
						}
					}
					else{
						ar[temp+6].setBackground(Color.cyan);
					}
					if(ar[temp+10].getIcon()!=null){
						if(GetRed(ar, temp+10)){
							ar[temp+10].setBackground(Color.green);
						}
					}
					else{
						ar[temp+10].setBackground(Color.cyan);
					}
					if(ar[temp+15].getIcon()!=null){
						if(GetRed(ar, temp+15)){
							ar[temp+15].setBackground(Color.green);
						}
					}
					else{
						ar[temp+15].setBackground(Color.cyan);
					}
					if(ar[temp+17].getIcon()!=null){
						if(GetRed(ar, temp+17)){
							ar[temp+17].setBackground(Color.green);
						}
					}
					else{
						ar[temp+17].setBackground(Color.cyan);
					}
					if(ar[temp-6].getIcon()!=null){
						if(GetRed(ar, temp-6)){
							ar[temp-6].setBackground(Color.green);
						}
					}
					else{
						ar[temp-6].setBackground(Color.cyan);
					}
					if(ar[temp-10].getIcon()!=null){
						if(GetRed(ar, temp-10)){
							ar[temp-10].setBackground(Color.green);
						}
					}
					else{
						ar[temp-10].setBackground(Color.cyan);
					}
				}
				else if(temp>=51 && temp<=54 || temp>=59 && temp<=62){
						if(ar[temp-6].getIcon()!=null){
							if(GetRed(ar, temp-6)){
								ar[temp-6].setBackground(Color.green);
							}
						}
						else{
							ar[temp-6].setBackground(Color.cyan);
						}
						if(ar[temp-10].getIcon()!=null){
							if(GetRed(ar, temp-10)){
								ar[temp-10].setBackground(Color.green);
							}
						}
						else{
							ar[temp-10].setBackground(Color.cyan);
						}
						if(ar[temp-15].getIcon()!=null){
							if(GetRed(ar, temp-15)){
								ar[temp-15].setBackground(Color.green);
							}
						}
						else{
							ar[temp-15].setBackground(Color.cyan);
						}
						if(ar[temp-17].getIcon()!=null){
							if(GetRed(ar, temp-17)){
								ar[temp-17].setBackground(Color.green);
							}
						}
						else{
							ar[temp-17].setBackground(Color.cyan);
						}
						if(ar[temp+6].getIcon()!=null){
							if(GetRed(ar, temp+6)){
								ar[temp+6].setBackground(Color.green);
							}
						}
						else{
							ar[temp+6].setBackground(Color.cyan);
						}
						if(ar[temp+10].getIcon()!=null){
							if(GetRed(ar, temp+10)){
								ar[temp+10].setBackground(Color.green);
							}
						}
						else{
							ar[temp+10].setBackground(Color.cyan);
						}
					}
					else if(temp==1 || temp==9 || temp==17 || temp==25 || temp==33 || temp==41 || temp==49 || temp==57){
						try{
							if(ar[temp+10].getIcon()!=null){
							if(GetRed(ar, temp+10)){
								ar[temp+10].setBackground(Color.green);
							}
						}
						else{
							ar[temp+10].setBackground(Color.cyan);
						}
						}catch(Exception e){
							
						}
						try{
						if(ar[temp+17].getIcon()!=null){
							if(GetRed(ar, temp+17)){
								ar[temp+17].setBackground(Color.green);
							}
						}
						else{
							ar[temp+17].setBackground(Color.cyan);
						}
						}catch(Exception e2){
							System.out.println();
						}
						try{
						if(ar[temp-6].getIcon()!=null){
							if(GetRed(ar, temp-6)){
								ar[temp-6].setBackground(Color.green);
							}
						}
						else{
							ar[temp-6].setBackground(Color.cyan);
						}
						}catch(Exception e3){
							System.out.println();
						}
						if(ar[temp-15].getIcon()!=null){
							if(GetRed(ar, temp-15)){
								ar[temp-15].setBackground(Color.green);
							}
						}
						else{
							ar[temp-15].setBackground(Color.cyan);
						}
					}
					else if(temp==2 || temp==10 || temp==18 || temp==26 || temp==34 || temp==42 || temp==50 || temp==58){
						try{
						if(ar[temp+10].getIcon()!=null){
							if(GetRed(ar, temp+10)){
								ar[temp+10].setBackground(Color.green);
							}
						}
						else{
							ar[temp+10].setBackground(Color.cyan);
						}
						}catch(Exception e){
							System.out.println();
						}
						try{
						if(ar[temp+15].getIcon()!=null){
							if(GetRed(ar, temp+15)){
								ar[temp+15].setBackground(Color.green);
							}
						}
						else{
							ar[temp+15].setBackground(Color.cyan);
						}
						}catch(Exception e2){
							System.out.println();
						}
						try{
						if(ar[temp+17].getIcon()!=null){
							if(GetRed(ar, temp+17)){
								ar[temp+17].setBackground(Color.green);
							}
						}
						else{
							ar[temp+17].setBackground(Color.cyan);
						}
						}catch(Exception e3){
							System.out.println();
						}
						try{
						if(ar[temp-6].getIcon()!=null){
							if(GetRed(ar, temp-6)){
								ar[temp-6].setBackground(Color.green);
							}
						}
						else{
							ar[temp-6].setBackground(Color.cyan);
						}
						}catch(Exception e4){
							System.out.println();
						}
						try{
						if(ar[temp-15].getIcon()!=null){
							if(GetRed(ar, temp-15)){
								ar[temp-15].setBackground(Color.green);
							}
						}
						else{
							ar[temp-15].setBackground(Color.cyan);
						}
						}catch(Exception e5){
							System.out.println();
						}
						if(ar[temp-17].getIcon()!=null){
							if(GetRed(ar, temp-17)){
								ar[temp-17].setBackground(Color.green);
							}
						}
						else{
							ar[temp-17].setBackground(Color.cyan);
						}
					}
					else if(temp==8 || temp==16 || temp==24 || temp==32 || temp==40 || temp==48 || temp==56 || temp==64){
						try{
						if(ar[temp+6].getIcon()!=null){
							if(GetRed(ar, temp+6)){
								ar[temp+6].setBackground(Color.green);
							}
						}
						else{
							ar[temp+6].setBackground(Color.cyan);
						}
						}catch(Exception e2){
							System.out.println();
						}
						try{
						if(ar[temp-10].getIcon()!=null){
							if(GetRed(ar, temp-10)){
								ar[temp-10].setBackground(Color.green);
							}
						}
						else{
							ar[temp-10].setBackground(Color.cyan);
						}
						}catch(Exception e3){
							System.out.println();
						}
						try{
						if(ar[temp+15].getIcon()!=null){
							if(GetRed(ar, temp+15)){
								ar[temp+15].setBackground(Color.green);
							}
						}
						else{
							ar[temp+15].setBackground(Color.cyan);
						}
						}catch(Exception e4){
							System.out.println();
						}
						if(ar[temp-17].getIcon()!=null){
							if(GetRed(ar, temp-17)){
								ar[temp-17].setBackground(Color.green);
							}
						}
						else{
							ar[temp-17].setBackground(Color.cyan);
						}
					}
					else if(temp==7 || temp==15 || temp==23 || temp==31 || temp==39 || temp==47 || temp==55 || temp==63){
						try{
							if(ar[temp+6].getIcon()!=null){
								if(GetRed(ar, temp+6)){
									ar[temp+6].setBackground(Color.green);
								}
							}
							else{
								ar[temp+6].setBackground(Color.cyan);
							}
							}catch(Exception e){
								System.out.println();
							}
							try{
							if(ar[temp+15].getIcon()!=null){
								if(GetRed(ar, temp+15)){
									ar[temp+15].setBackground(Color.green);
								}
							}
							else{
								ar[temp+15].setBackground(Color.cyan);
							}
							}catch(Exception e2){
								System.out.println();
							}
							try{
							if(ar[temp+17].getIcon()!=null){
								if(GetRed(ar, temp+17)){
									ar[temp+17].setBackground(Color.green);
								}
							}
							else{
								ar[temp+17].setBackground(Color.cyan);
							}
							}catch(Exception e3){
								System.out.println();
							}
							try{
							if(ar[temp-10].getIcon()!=null){
								if(GetRed(ar, temp-10)){
									ar[temp-10].setBackground(Color.green);
								}
							}
							else{
								ar[temp-10].setBackground(Color.cyan);
							}
							}catch(Exception e4){
								System.out.println();
							}
							try{
							if(ar[temp-15].getIcon()!=null){
								if(GetRed(ar, temp-15)){
									ar[temp-15].setBackground(Color.green);
								}
							}
							else{
								ar[temp-15].setBackground(Color.cyan);
							}
							}catch(Exception e5){
								System.out.println();
							}
							if(ar[temp-17].getIcon()!=null){
								if(GetRed(ar, temp-17)){
									ar[temp-17].setBackground(Color.green);
								}
							}
							else{
								ar[temp-17].setBackground(Color.cyan);
							}
					}
			}
			else{
				if(ar[temp+6].getIcon()!=null){
					if(GetRed(ar, temp+6)){
						ar[temp+6].setBackground(Color.green);
					}
				}
				else{
					ar[temp+6].setBackground(Color.cyan);
				}
				if(ar[temp+10].getIcon()!=null){
					if(GetRed(ar, temp+10)){
						ar[temp+10].setBackground(Color.green);
					}
				}
				else{
					ar[temp+10].setBackground(Color.cyan);
				}
				if(ar[temp+15].getIcon()!=null){
					if(GetRed(ar, temp+15)){
						ar[temp+15].setBackground(Color.green);
					}
				}
				else{
					ar[temp+15].setBackground(Color.cyan);
				}
				if(ar[temp+17].getIcon()!=null){
					if(GetRed(ar, temp+17)){
						ar[temp+17].setBackground(Color.green);
					}
				}
				else{
					ar[temp+17].setBackground(Color.cyan);
				}
				if(ar[temp-6].getIcon()!=null){
					if(GetRed(ar, temp-6)){
						ar[temp-6].setBackground(Color.green);
					}
				}
				else{
					ar[temp-6].setBackground(Color.cyan);
				}
				if(ar[temp-10].getIcon()!=null){
					if(GetRed(ar, temp-10)){
						ar[temp-10].setBackground(Color.green);
					}
				}
				else{
					ar[temp-10].setBackground(Color.cyan);
				}
				if(ar[temp-15].getIcon()!=null){
					if(GetRed(ar, temp-15)){
						ar[temp-15].setBackground(Color.green);
					}
				}
				else{
					ar[temp-15].setBackground(Color.cyan);
				}
				if(ar[temp-17].getIcon()!=null){
					if(GetRed(ar, temp-17)){
						ar[temp-17].setBackground(Color.green);
					}
				}
				else{
					ar[temp-17].setBackground(Color.cyan);
				}
			}
			}catch(Exception e){
				System.out.println();
			}
		}
		boolean RkingIsNull(JButton jb[]){
			for(int i=1;i<=64;i++){
				if(jb[i].getIcon()==Rking){
					return false;
				}
				else{
					continue;
				}
			}
			return true;
		}
		boolean BkingIsNull(JButton jb[]){
			for(int i=1;i<=64;i++){
				if(jb[i].getIcon()==Bking){
					return false;
				}
				else{
					continue;
				}
			}
			return true;
		}
		boolean GetBlue(JButton arr[],int temp3){
			if(arr[temp3].getIcon()==Bking || arr[temp3].getIcon()==Bpawn || arr[temp3].getIcon()==Brook || arr[temp3].getIcon()==Bbishop || arr[temp3].getIcon()==Bqueen || arr[temp3].getIcon()==Bknight){
				return true;
			}
			else{
				return false;
			}
		}
		boolean GetRed(JButton arr[],int temp3){
			if(arr[temp3].getIcon()==Rking || arr[temp3].getIcon()==Rpawn || arr[temp3].getIcon()==Rrook || arr[temp3].getIcon()==Rbishop || arr[temp3].getIcon()==Rqueen || arr[temp3].getIcon()==Rknight){
				return true;
			}
			else{
				return false;
			}
		}
}